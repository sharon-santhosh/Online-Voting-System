package online_voting_system;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;


import online_voting_system.home_page;


public class admin_homepage extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					admin_homepage frame = new admin_homepage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public admin_homepage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(350, 100, 750, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setUndecorated(true); //To remove frame outline
		
		JSeparator separator = new JSeparator();
		separator.setBounds(162, 129, 422, 2);
		contentPane.add(separator);
		
		JLabel lblNewLabel = new JLabel("WELCOME ADMIN");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(25, 25, 112));
		lblNewLabel.setFont(new Font("Eras Light ITC", Font.BOLD, 50));
		lblNewLabel.setBounds(138, 55, 467, 63);
		contentPane.add(lblNewLabel);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(162, 42, 422, 2);
		contentPane.add(separator_1);
		
		
		JButton btnNewButton = new JButton("X");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(DISPOSE_ON_CLOSE);
			}
		});
		
		btnNewButton.setBackground(new Color(248, 248, 255));
		btnNewButton.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 15));
		btnNewButton.setForeground(new Color(128, 128, 128));
		btnNewButton.setBounds(702, 0, 48, 38);
		contentPane.add(btnNewButton);
		
		JButton btnLogout = new JButton("Logout");
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnLogout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				login_page login= new login_page();
				login.setVisible(true);
			}
		});
		btnLogout.setForeground(new Color(25, 25, 112));
		btnLogout.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 20));
		btnLogout.setBackground(new Color(245, 245, 245));
		btnLogout.setBounds(549, 358, 166, 47);
		contentPane.add(btnLogout);
		
		JButton btnManagePolls = new JButton("Manage polls");
		btnManagePolls.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				manage_votes manage= new manage_votes();
				manage.setVisible(true);
			}
		});
		
		btnManagePolls.setForeground(new Color(25, 25, 112));
		btnManagePolls.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 20));
		btnManagePolls.setBackground(new Color(245, 245, 245));
		btnManagePolls.setBounds(549, 216, 166, 47);
		contentPane.add(btnManagePolls);
		
		JButton btnManageVoters = new JButton("Manage voters");
		btnManageVoters.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				view_voters view= new view_voters();
				view.setVisible(true);
			}
		});
		btnManageVoters.setForeground(new Color(25, 25, 112));
		btnManageVoters.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 20));
		btnManageVoters.setBackground(new Color(245, 245, 245));
		btnManageVoters.setBounds(35, 216, 166, 47);
		contentPane.add(btnManageVoters);
		
		//Inserting an image
				JLabel lblNewLabel1 = new JLabel("");
				lblNewLabel1.setHorizontalAlignment(SwingConstants.CENTER);
				Image image= new ImageIcon(this.getClass().getResource("/conversation-icon.png")).getImage();
				lblNewLabel1.setIcon(new ImageIcon(image));
				lblNewLabel1.setBounds(224, 184, 302, 267);
				contentPane.add(lblNewLabel1);
				
				JButton btnAddCandidate = new JButton("Add candidate");
				btnAddCandidate.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						register_candidate register= new register_candidate();
						register.setVisible(true);
					}
				});
				
				btnAddCandidate.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
					}
				});
				btnAddCandidate.setForeground(new Color(25, 25, 112));
				btnAddCandidate.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 20));
				btnAddCandidate.setBackground(new Color(245, 245, 245));
				btnAddCandidate.setBounds(35, 358, 166, 47);
				contentPane.add(btnAddCandidate);
	}
}


