package online_voting_system;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;

import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.sql.*;
import java.text.SimpleDateFormat;

import javax.swing.*;
import java.awt.Cursor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import com.toedter.calendar.JDateChooser;

public class view_voters extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField textField_1;
	private JTextField textField_4;
	private JTextField textField;
	private JTextField textField_2;
	private JTextField textField_3;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					view_voters frame = new view_voters();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public view_voters() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(350, 100, 750, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setUndecorated(true); //To remove frame outline
		
		JSeparator separator = new JSeparator();
		separator.setBounds(223, 92, 298, 2);
		contentPane.add(separator);
		
		JLabel lblNewLabel = new JLabel("MANAGE VOTERS");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(25, 25, 112));
		lblNewLabel.setFont(new Font("Eras Light ITC", Font.BOLD, 35));
		lblNewLabel.setBounds(193, 32, 358, 63);
		contentPane.add(lblNewLabel);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(223, 32, 298, 2);
		contentPane.add(separator_1);
		
		JButton btnNewButton = new JButton("X");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(DISPOSE_ON_CLOSE);
			}
		});
		btnNewButton.setBackground(new Color(245, 245, 245));
		btnNewButton.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 15));
		btnNewButton.setForeground(new Color(25, 25, 112));
		btnNewButton.setBounds(702, 0, 48, 38);
		contentPane.add(btnNewButton);
		
		JButton btnLoad_table = new JButton("Load table");
		btnLoad_table.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnLoad_table.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnLoad_table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try{  
					Class.forName("com.mysql.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/online_voting_system","root","Sh@10m123");  
					Statement stmt=con.createStatement();
					
					String query= "select name, email, dob, gender from user order by name";
					PreparedStatement pst=con.prepareStatement(query);
					ResultSet rs= pst.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(rs));
					table.setEnabled(false);
					con.close();
				}catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setEnabled(false);
		scrollPane.setFocusTraversalKeysEnabled(false);
		scrollPane.setFocusable(false);
		scrollPane.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 5));
		scrollPane.setForeground(new Color(25, 25, 112));
		scrollPane.setBackground(new Color(245, 245, 245));
		scrollPane.setBounds(20, 158, 474, 273);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		btnLoad_table.setBackground(new Color(245, 245, 245));
		btnLoad_table.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 14));
		btnLoad_table.setForeground(new Color(25, 25, 112));
		btnLoad_table.setBounds(20, 124, 103, 23);
		contentPane.add(btnLoad_table);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				admin_homepage admin= new admin_homepage();
				admin.setVisible(true);
			}
		});
		btnBack.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnBack.setForeground(new Color(25, 25, 112));
		btnBack.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 14));
		btnBack.setBackground(new Color(245, 245, 245));
		btnBack.setBounds(391, 124, 103, 23);
		contentPane.add(btnBack);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnUpdate.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/online_voting_system","root","Sh@10m123"); 
					String query="update user set email = '"+textField_1.getText()+"', dob = '"+textField_2.getText()+"', "
								  + "gender = '"+textField_3.getText()+"' where name = '"+textField.getText()+"'";
					
				    PreparedStatement preparedStmt = con.prepareStatement(query);
				    preparedStmt.executeUpdate();
				    JOptionPane.showMessageDialog(null,"Details successfully updated. Please load table again to refresh.");
    				
				    textField.setText(null);
    				textField_1.setText(null);
    				textField_2.setText(null);
    				textField_3.setText(null);   
					con.close();
					
			} catch(Exception e1) {
				e1.printStackTrace();
			}
			}
		});
		btnUpdate.setForeground(new Color(25, 25, 112));
		btnUpdate.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 14));
		btnUpdate.setBackground(new Color(245, 245, 245));
		btnUpdate.setBounds(601, 442, 128, 25);
		contentPane.add(btnUpdate);
		
		JButton btnFetch = new JButton("Fetch");
		btnFetch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnFetch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/online_voting_system","root","Sh@10m123"); 
					Statement stmt=con.createStatement();
					ResultSet rs=stmt.executeQuery("select email, dob, gender from user where name = '"+textField.getText()+"'");
					while(rs.next())
					{
						
						textField_1.setText(rs.getString(1));
						textField_2.setText(rs.getString(2));
						textField_3.setText(rs.getString(3));
					}
			} catch(Exception e1) {
				e1.printStackTrace();
			}
			}
		});
		btnFetch.setForeground(new Color(25, 25, 112));
		btnFetch.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 14));
		btnFetch.setBackground(new Color(245, 245, 245));
		btnFetch.setBounds(601, 211, 128, 23);
		contentPane.add(btnFetch);
		
		JLabel lblNewLabel_1 = new JLabel("X");
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(DISPOSE_ON_CLOSE);
			}
		});
		lblNewLabel_1.setForeground(new Color(0, 128, 128));
		lblNewLabel_1.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 20));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(698, 0, 52, 34);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblUsername = new JLabel("Name");
		lblUsername.setForeground(new Color(25, 25, 112));
		lblUsername.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 15));
		lblUsername.setBackground(new Color(245, 245, 245));
		lblUsername.setBounds(509, 177, 86, 23);
		contentPane.add(lblUsername);
		
		JLabel lblEmailId = new JLabel("Email ID");
		lblEmailId.setForeground(new Color(25, 25, 112));
		lblEmailId.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 15));
		lblEmailId.setBackground(new Color(245, 245, 245));
		lblEmailId.setBounds(509, 267, 86, 32);
		contentPane.add(lblEmailId);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(601, 267, 128, 31);
		contentPane.add(textField_1);
		
		JLabel lblDateOfBirth = new JLabel("Date of birth");
		lblDateOfBirth.setForeground(new Color(25, 25, 112));
		lblDateOfBirth.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 15));
		lblDateOfBirth.setBackground(new Color(245, 245, 245));
		lblDateOfBirth.setBounds(509, 326, 86, 31);
		contentPane.add(lblDateOfBirth);
		
		JLabel lblGender = new JLabel("Gender");
		lblGender.setForeground(new Color(25, 25, 112));
		lblGender.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 15));
		lblGender.setBackground(new Color(245, 245, 245));
		lblGender.setBounds(509, 384, 86, 30);
		contentPane.add(lblGender);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					if (textField_1.getText().trim().isEmpty())
					{
	                    JOptionPane.showMessageDialog(btnDelete, "Enter voter name to search and delete.");
	                	textField.setText(null);
	    				textField_1.setText(null);
	    				textField_2.setText(null);
	    				return;				
					}
					Class.forName("com.mysql.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/online_voting_system","root","Sh@10m123"); 
					Statement stmt=con.createStatement();
					stmt.execute("delete from user where name= '"+textField.getText()+"'");
                    JOptionPane.showMessageDialog(btnDelete, "Voter successfully deleted."+ "/n"+"Please load the table again to refresh");
                	textField.setText(null);
    				textField_1.setText(null);
    				textField_2.setText(null);
    				textField_3.setText(null);
                    con.close();
                } catch (Exception exception) {
                    JOptionPane.showMessageDialog(btnDelete, exception);
                }
			}
		});
		btnDelete.setForeground(new Color(25, 25, 112));
		btnDelete.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 14));
		btnDelete.setBackground(new Color(245, 245, 245));
		btnDelete.setBounds(391, 442, 103, 25);
		contentPane.add(btnDelete);
		
		JButton btnClearTable = new JButton("Clear table");
		btnClearTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try{  
					Class.forName("com.mysql.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/online_voting_system","root","Sh@10m123");  
					Statement stmt=con.createStatement();
					
					String query= "truncate user";
					JOptionPane.showMessageDialog(btnDelete, "Table successfully deleted."+ "/n"+"Please load the table again to refresh");
					PreparedStatement pst=con.prepareStatement(query);
					ResultSet rs= pst.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(rs));
					table.setEnabled(false);
					con.close();
				}catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});

		btnClearTable.setForeground(new Color(25, 25, 112));
		btnClearTable.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 14));
		btnClearTable.setBackground(new Color(245, 245, 245));
		btnClearTable.setBounds(20, 442, 103, 25);
		contentPane.add(btnClearTable);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(601, 169, 128, 31);
		contentPane.add(textField);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(601, 326, 128, 31);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(601, 383, 128, 31);
		contentPane.add(textField_3);
		
	}
}


