package online_voting_system;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.*;
import java.text.SimpleDateFormat;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.JScrollBar;
import javax.swing.JSpinner;
import javax.swing.SpinnerListModel;
import java.awt.ComponentOrientation;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.Choice;
import javax.swing.JTable;
import javax.swing.JFormattedTextField;
import com.toedter.calendar.JDateChooser;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import com.toedter.calendar.JCalendar;
import com.toedter.components.JSpinField;
import javax.swing.JTextArea;
import javax.swing.ActionMap;
import javax.swing.JButton;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.BigInteger;

import javax.swing.JRadioButton;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import com.toedter.components.JLocaleChooser;
import javax.swing.DropMode;
import javax.swing.ImageIcon;

public class register extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					register frame = new register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public register() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(350, 100, 750, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setUndecorated(true); //To remove frame outline
		
		JLabel lblUserRegistrationForm = new JLabel("REGISTRATION");
		lblUserRegistrationForm.setHorizontalAlignment(SwingConstants.CENTER);
		lblUserRegistrationForm.setFont(new Font("Eras Light ITC", Font.PLAIN, 50));
		lblUserRegistrationForm.setForeground(new Color(25, 25, 112));
		lblUserRegistrationForm.setBounds(200, 21, 331, 69);
		contentPane.add(lblUserRegistrationForm);
		
		textField = new JTextField();
		textField.setBounds(363, 151, 202, 34);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(200, 91, 331, 2);
		contentPane.add(separator);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setForeground(new Color(25, 25, 112));
		lblName.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 20));
		lblName.setBounds(156, 151, 145, 34);
		contentPane.add(lblName);
		
		JLabel lblEmailID = new JLabel("Email ID:");
		lblEmailID.setForeground(new Color(25, 25, 112));
		lblEmailID.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 20));
		lblEmailID.setBounds(156, 211, 113, 34);
		contentPane.add(lblEmailID);
		
		textField_1 = new JTextField();
		textField_1.setBounds(363, 211, 202, 34);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblDOB = new JLabel("Date of birth:");
		lblDOB.setForeground(new Color(25, 25, 112));
		lblDOB.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 20));
		lblDOB.setBounds(156, 276, 113, 34);
		contentPane.add(lblDOB);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(363, 273, 202, 34);
		contentPane.add(dateChooser);
		
		JLabel lblGender = new JLabel("Gender:");
		lblGender.setForeground(new Color(25, 25, 112));
		lblGender.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 20));
		lblGender.setBounds(156, 332, 113, 34);
		contentPane.add(lblGender);
		
		JRadioButton rdbtnMale = new JRadioButton("Male");
		rdbtnMale.setHorizontalAlignment(SwingConstants.CENTER);
		rdbtnMale.setBackground(new Color(255, 255, 255));
		rdbtnMale.setForeground(new Color(25, 25, 112));
		rdbtnMale.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 15));
		rdbtnMale.setBounds(363, 332, 89, 34);
		contentPane.add(rdbtnMale);
		
		JRadioButton rdbtnFemale = new JRadioButton("Female");
		rdbtnFemale.setForeground(new Color(25, 25, 112));
		rdbtnFemale.setHorizontalAlignment(SwingConstants.CENTER);
		rdbtnFemale.setBackground(new Color(255, 255, 255));
		rdbtnFemale.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 15));
		rdbtnFemale.setBounds(476, 332, 89, 34);
		contentPane.add(rdbtnFemale);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setForeground(new Color(25, 25, 112));
		lblPassword.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 20));
		lblPassword.setBounds(156, 387, 113, 34);
		contentPane.add(lblPassword);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(363, 387, 202, 34);
		contentPane.add(textField_2);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		
		btnRegister.setBackground(new Color(245, 245, 245));
		btnRegister.setForeground(new Color(25, 25, 112));
		btnRegister.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnRegister.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 20));
		btnRegister.addMouseListener(new MouseAdapter()  {
			public void mouseClicked(MouseEvent e) {
				String Name= textField.getText();
                String EmailID = textField_1.getText();
                String Password= textField_2.getText();
                

                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String DOB = dateFormat.format(dateChooser.getDate());
                
                
                
                String msg = "" + Name;
                msg += " \n";
                
                try {
                    
                	Class.forName("com.mysql.jdbc.Driver");  
                	Connection con= DriverManager.getConnection ("jdbc:mysql://localhost:3306/online_voting_system","root","Sh@10m123"); 
                	Statement stmt=con.createStatement();
                    
                    if (rdbtnMale.isSelected()) 
                    {
                        String query = "INSERT INTO user (name, email, dob, gender, password) values ('" + Name + "','" + EmailID + "','" + DOB + "','" + "Male" + "','"+ Password+"')";
                    	
                        
                        boolean x = stmt.execute(query);
                        if (x) {
                        	JOptionPane.showMessageDialog(btnRegister,"Unexpected error occured. Please contact ADMIN.");
                        } else {
                        	JOptionPane.showMessageDialog(btnRegister, "Welcome, " + msg + "Your account is successfully created."+ "\n" + 
                        												"Please login into your account to continue voting.");
                        	
            				textField.setText(null);
            				textField_1.setText(null);
            				dateChooser.setDate(null);
            				rdbtnMale.setSelected(false);
            				rdbtnFemale.setSelected(false);    
            				textField_2.setText(null);
                        }
                    }       	
                    else if(rdbtnFemale.isSelected()) 
                    {
                    	 String query = "INSERT INTO user (name, email, dob, gender, password) values ('" + Name + "','" + EmailID + "','" + DOB + "','" + "Female" + "','"+ Password+"')";
                        
                        boolean x = stmt.execute(query);
                        if (x) {
                        	JOptionPane.showMessageDialog(btnRegister,"Unexpected error occured. Please contact ADMIN.");
                        } else {
                        	JOptionPane.showMessageDialog(btnRegister, "Welcome, " + msg + "Your account is successfully created." + "\n" + 
                        												"Please login into your account to continue voting.");
                        	
                        	textField.setText(null);
            				textField_1.setText(null);
            				dateChooser.setDate(null);
            				rdbtnMale.setSelected(false);
            				rdbtnFemale.setSelected(false);    
            				textField_2.setText(null);
                        }
                    }
                    
                    con.close();
                    
                } catch (Exception exception) {
                    JOptionPane.showMessageDialog(btnRegister, exception);
                }
            }
			}
        );
		
		btnRegister.setBounds(612, 211, 113, 43);
		contentPane.add(btnRegister);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addMouseListener(new MouseAdapter() {
		
			public void mouseClicked(MouseEvent e) {
				textField.setText(null);
				textField_1.setText(null);
				dateChooser.setDate(null);
				rdbtnMale.setSelected(false);
				rdbtnFemale.setSelected(false);    
				textField_2.setText(null);
				
			}
		});
		btnReset.setBackground(new Color(245, 245, 245));
		btnReset.setForeground(new Color(25, 25, 112));
		btnReset.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 20));
		btnReset.setBounds(612, 268, 113, 43);
		contentPane.add(btnReset);
		
		JButton btnClose = new JButton("Back");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnClose.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				login_page login= new login_page();
				login.setVisible(true);
			}
		});
		btnClose.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 20));
		btnClose.setBackground(new Color(245, 245, 245));
		btnClose.setForeground(new Color(25, 25, 112));
		btnClose.setBounds(612, 326, 113, 43);
		contentPane.add(btnClose);
		
		JButton btnNewButton = new JButton("X");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(DISPOSE_ON_CLOSE);
			}
		});
		btnNewButton.setBackground(new Color(248, 248, 255));
		btnNewButton.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 15));
		btnNewButton.setForeground(new Color(128, 128, 128));
		btnNewButton.setBounds(702, 0, 48, 38);
		contentPane.add(btnNewButton);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(200, 21, 331, 2);
		contentPane.add(separator_1);
		
		
	}
}



