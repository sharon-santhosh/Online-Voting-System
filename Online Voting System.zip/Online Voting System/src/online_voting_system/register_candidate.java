package online_voting_system;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.*;
import java.text.SimpleDateFormat;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.JScrollBar;
import javax.swing.JSpinner;
import javax.swing.SpinnerListModel;
import java.awt.ComponentOrientation;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.Choice;
import javax.swing.JTable;
import javax.swing.JFormattedTextField;
import com.toedter.calendar.JDateChooser;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import com.toedter.calendar.JCalendar;
import com.toedter.components.JSpinField;
import javax.swing.JTextArea;
import javax.swing.ActionMap;
import javax.swing.JButton;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.BigInteger;

import javax.swing.JRadioButton;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import com.toedter.components.JLocaleChooser;
import javax.swing.DropMode;
import javax.swing.ImageIcon;

public class register_candidate extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					register_candidate frame = new register_candidate();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public register_candidate() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(350, 100, 750, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setUndecorated(true);
		
		JLabel lblUserRegistrationForm = new JLabel("CANDIDATE REGISTRATION");
		lblUserRegistrationForm.setHorizontalAlignment(SwingConstants.CENTER);
		lblUserRegistrationForm.setFont(new Font("Eras Light ITC", Font.PLAIN, 45));
		lblUserRegistrationForm.setForeground(new Color(25, 25, 112));
		lblUserRegistrationForm.setBounds(95, 21, 540, 69);
		contentPane.add(lblUserRegistrationForm);
		
		
		JButton btnNewButton = new JButton("X");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(DISPOSE_ON_CLOSE);
			}
		});
		
		btnNewButton.setBackground(new Color(248, 248, 255));
		btnNewButton.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 15));
		btnNewButton.setForeground(new Color(128, 128, 128));
		btnNewButton.setBounds(702, 0, 48, 38);
		contentPane.add(btnNewButton);
		
		JButton btnClose = new JButton("Back");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnClose.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				admin_homepage admin= new admin_homepage();
				admin.setVisible(true);
			}
		});
		btnClose.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 18));
		btnClose.setBackground(new Color(245, 245, 245));
		btnClose.setForeground(new Color(25, 25, 112));
		btnClose.setBounds(322, 417, 87, 35);
		contentPane.add(btnClose);
		
		
		JLabel lblName = new JLabel("Candidate ID:");
		lblName.setForeground(new Color(25, 25, 112));
		lblName.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 20));
		lblName.setBounds(115, 247, 145, 48);
		contentPane.add(lblName);
		
		JLabel lblEmailID = new JLabel("Candidate Name:");
		lblEmailID.setForeground(new Color(25, 25, 112));
		lblEmailID.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 20));
		lblEmailID.setBounds(115, 140, 160, 49);
		contentPane.add(lblEmailID);
		
		JLabel lblDOB = new JLabel("Candidate Party:");
		lblDOB.setForeground(new Color(25, 25, 112));
		lblDOB.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 20));
		lblDOB.setBounds(115, 333, 172, 47);
		contentPane.add(lblDOB);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		
		btnRegister.setBackground(new Color(245, 245, 245));
		btnRegister.setForeground(new Color(25, 25, 112));
		btnRegister.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnRegister.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 18));
		btnRegister.addMouseListener(new MouseAdapter()  {
			public void mouseClicked(MouseEvent e) {
				String ID= textField.getText();
                String Name = textField_1.getText();
                String Party= textField_2.getText();              
               
                try {
                    
                	Class.forName("com.mysql.jdbc.Driver");  
                	Connection con= DriverManager.getConnection ("jdbc:mysql://localhost:3306/online_voting_system","root","Sh@10m123"); 
                	Statement stmt=con.createStatement();

                        String query = "INSERT INTO candidates (candidate_id, candidate_name, candidate_party) values ('" + ID + "','" + Name + "','" +
                                 Party + "')";

                        boolean x = stmt.execute(query);
                        if (x) {
                        	JOptionPane.showMessageDialog(btnRegister,"Unexpected error occured. Please contact ADMIN.");
                        } else {
                        	JOptionPane.showMessageDialog(btnRegister, "Candidate successfully registered.");
            				textField.setText(null);
            				textField_1.setText(null); 
            				textField_2.setText(null);
                        }
                    
                    con.close();
                } catch (Exception exception) {
                    JOptionPane.showMessageDialog(btnRegister, exception);
                }
            }
			}
        );
		
		btnRegister.setBounds(565, 248, 98, 38);
		contentPane.add(btnRegister);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(322, 247, 202, 48);
		contentPane.add(textField);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(322, 140, 202, 49);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(322, 332, 202, 48);
		contentPane.add(textField_2);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnReset.addMouseListener(new MouseAdapter() {
		
			public void mouseClicked(MouseEvent e) {
				textField.setText(null);
				textField_1.setText(null);   
				textField_2.setText(null);
				
			}
		});
		btnReset.setBackground(new Color(245, 245, 245));
		btnReset.setForeground(new Color(25, 25, 112));
		btnReset.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 18));
		btnReset.setBounds(437, 417, 87, 35);
		contentPane.add(btnReset);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String id= textField.getText();
                String name = textField_1.getText();
                String party = textField_2.getText();
                
                try {

    				String query = "";
    				Class.forName("com.mysql.jdbc.Driver");  
                	Connection con= DriverManager.getConnection ("jdbc:mysql://localhost:3306/online_voting_system","root","Sh@10m123"); 
                	Statement stmt=con.createStatement();
                	
                	query = "UPDATE candidates set candidate_id='"+id+"', candidate_name='"+name+"', candidate_party='"+party+"' where candidate_id='"+id+"'";
                    boolean x = stmt.execute(query);
                    if (x) {
                    	JOptionPane.showMessageDialog(btnUpdate,"Unexpected error occured.");
                    } else {
                    	JOptionPane.showMessageDialog(btnUpdate, "Candidates updated successfully.");
                    	textField.setText(null);
        				textField_1.setText(null);
        				textField_2.setText(null);
                    }
                    con.close();
                } catch (Exception exception) {
                    JOptionPane.showMessageDialog(btnUpdate, exception);
                }
                
			}
		});
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnUpdate.setForeground(new Color(25, 25, 112));
		btnUpdate.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 18));
		btnUpdate.setBackground(new Color(245, 245, 245));
		btnUpdate.setBounds(565, 297, 98, 37);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					if (textField_1.getText().trim().isEmpty())
					{
	                    JOptionPane.showMessageDialog(btnDelete, "Enter candidate name to search and delete.");
	                	textField.setText(null);
	    				textField_1.setText(null);
	    				textField_2.setText(null);
	    				return;				
					}
					Class.forName("com.mysql.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/online_voting_system","root","Sh@10m123"); 
					Statement stmt=con.createStatement();
					stmt.execute("delete from candidates where candidate_name= '"+textField.getText()+"'");
                    JOptionPane.showMessageDialog(btnDelete, textField_1.getText()+" successfully deleted.");
                	textField.setText(null);
    				textField_1.setText(null);
    				textField_2.setText(null);
                    con.close();
                } catch (Exception exception) {
                    JOptionPane.showMessageDialog(btnDelete, exception);
                }
			}
		});
			
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnDelete.setForeground(new Color(25, 25, 112));
		btnDelete.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 18));
		btnDelete.setBackground(new Color(245, 245, 245));
		btnDelete.setBounds(565, 345, 98, 35);
		contentPane.add(btnDelete);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(89, 212, 590, 2);
		contentPane.add(separator_2);
		
		JSeparator separator_2_1 = new JSeparator();
		separator_2_1.setBounds(89, 114, 590, 2);
		contentPane.add(separator_2_1);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					if (textField_1.getText().trim().isEmpty())
					{
	                    JOptionPane.showMessageDialog(btnSearch, "Enter candidate name to search.");
	                	textField_1.setText(null);
	    				textField.setText(null);
	    				textField_2.setText(null);
	    				return;				
					}
					Class.forName("com.mysql.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/online_voting_system","root","Sh@10m123"); 
					Statement stmt=con.createStatement();
					ResultSet rs=stmt.executeQuery("select candidate_id, candidate_party, votes from candidates where candidate_name= '"+textField_1.getText()+"'");
					boolean rsval = rs.next();
					if (rsval == false){
	                    JOptionPane.showMessageDialog(btnSearch, "Candidate does not exist.");
	                    return;
						}
					while (rsval)
                    {
                    	textField.setText(rs.getString(1));
                    	textField_2.setText(rs.getString(2));
                    	rsval = rs.next();
                    }
                     con.close();
                    }
				catch (Exception exception) {
                    JOptionPane.showMessageDialog(btnSearch, exception);
                }
            }
			}
        );
			
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnSearch.setForeground(new Color(25, 25, 112));
		btnSearch.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 18));
		btnSearch.setBackground(new Color(245, 245, 245));
		btnSearch.setBounds(565, 146, 98, 38);
		contentPane.add(btnSearch);
	}
}



