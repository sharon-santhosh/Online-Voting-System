package online_voting_system;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

public class manage_votes extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField textField;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_1;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					manage_votes frame = new manage_votes();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public manage_votes() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(350, 100, 750, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setUndecorated(true); //To remove frame outline
		
		JSeparator separator = new JSeparator();
		separator.setBounds(223, 92, 298, 2);
		contentPane.add(separator);
		
		JLabel lblNewLabel = new JLabel("MANAGE VOTES");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(25, 25, 112));
		lblNewLabel.setFont(new Font("Eras Light ITC", Font.BOLD, 35));
		lblNewLabel.setBounds(193, 32, 358, 63);
		contentPane.add(lblNewLabel);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(223, 32, 298, 2);
		contentPane.add(separator_1);
		
		JButton btnNewButton = new JButton("X");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(DISPOSE_ON_CLOSE);
			}
		});
		btnNewButton.setBackground(new Color(245, 245, 245));
		btnNewButton.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 15));
		btnNewButton.setForeground(new Color(25, 25, 112));
		btnNewButton.setBounds(702, 0, 48, 38);
		contentPane.add(btnNewButton);
		
		JButton btnLoad_table = new JButton("Load table");
		btnLoad_table.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnLoad_table.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnLoad_table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				try{  
					Class.forName("com.mysql.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/online_voting_system","root","Sh@10m123");  
					Statement stmt=con.createStatement();
					
					String query= "select candidate_id, candidate_name, candidate_party, votes from candidates order by candidate_id";
					PreparedStatement pst=con.prepareStatement(query);
					ResultSet rs= pst.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(rs));
					table.setEnabled(false);
					con.close();
				}catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setEnabled(false);
		scrollPane.setFocusTraversalKeysEnabled(false);
		scrollPane.setFocusable(false);
		scrollPane.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 5));
		scrollPane.setForeground(new Color(25, 25, 112));
		scrollPane.setBackground(new Color(245, 245, 245));
		scrollPane.setBounds(20, 135, 452, 343);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);

		btnLoad_table.setBackground(new Color(245, 245, 245));
		btnLoad_table.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 14));
		btnLoad_table.setForeground(new Color(25, 25, 112));
		btnLoad_table.setBounds(20, 101, 103, 23);
		contentPane.add(btnLoad_table);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				admin_homepage admin= new admin_homepage();
				admin.setVisible(true);
			}
		});
		btnBack.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnBack.setForeground(new Color(25, 25, 112));
		btnBack.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 14));
		btnBack.setBackground(new Color(245, 245, 245));
		btnBack.setBounds(367, 101, 103, 23);
		contentPane.add(btnBack);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnSave.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/online_voting_system","root","Sh@10m123"); 
					String query="update candidates set candidate_name = '"+textField_1.getText()+"', candidate_party = '"+textField_2.getText()+"', votes = '"+textField_3.getText()+"' where candidate_id = '"+textField.getText()+"'";
					
				    PreparedStatement preparedStmt = con.prepareStatement(query);
				    preparedStmt.executeUpdate();
				    JOptionPane.showMessageDialog(null,"Details successfully updated. Please load table again to refresh.");
    				
				    textField.setText(null);
    				textField_1.setText(null);
    				textField_2.setText(null);
    				textField_3.setText(null);   
					con.close();
					
			} catch(Exception e1) {
				e1.printStackTrace();
			}
			}
		});
		btnSave.setForeground(new Color(25, 25, 112));
		btnSave.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 14));
		btnSave.setBackground(new Color(245, 245, 245));
		btnSave.setBounds(616, 443, 124, 25);
		contentPane.add(btnSave);
		
		JButton btnFetch = new JButton("Fetch");
		btnFetch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnFetch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/online_voting_system","root","Sh@10m123"); 
					Statement stmt=con.createStatement();
					ResultSet rs=stmt.executeQuery("select candidate_name, candidate_party, votes from candidates where candidate_id = '"+textField.getText()+"'");
					while(rs.next())
					{
						
						textField_1.setText(rs.getString(1));
						textField_2.setText(rs.getString(2));
						textField_3.setText(rs.getString(3));
						
					}
			} catch(Exception e1) {
				e1.printStackTrace();
			}
			}
		});
		btnFetch.setForeground(new Color(25, 25, 112));
		btnFetch.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 14));
		btnFetch.setBackground(new Color(245, 245, 245));
		btnFetch.setBounds(616, 169, 124, 23);
		contentPane.add(btnFetch);
		
		JLabel lblcandidateID = new JLabel("Candidate ID:");
		lblcandidateID.setForeground(new Color(25, 25, 112));
		lblcandidateID.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 15));
		lblcandidateID.setBackground(new Color(245, 245, 245));
		lblcandidateID.setBounds(493, 129, 103, 23);
		contentPane.add(lblcandidateID);
		
		JLabel lblcandidateName = new JLabel("Candidate Name:");
		lblcandidateName.setForeground(new Color(25, 25, 112));
		lblcandidateName.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 15));
		lblcandidateName.setBackground(new Color(245, 245, 245));
		lblcandidateName.setBounds(493, 225, 124, 32);
		contentPane.add(lblcandidateName);
		
		JLabel lblcandidateParty = new JLabel("Candidate Party:");
		lblcandidateParty.setForeground(new Color(25, 25, 112));
		lblcandidateParty.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 15));
		lblcandidateParty.setBackground(new Color(245, 245, 245));
		lblcandidateParty.setBounds(493, 284, 124, 31);
		contentPane.add(lblcandidateParty);
		
		JLabel lblVotes = new JLabel("Votes:");
		lblVotes.setForeground(new Color(25, 25, 112));
		lblVotes.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 15));
		lblVotes.setBackground(new Color(245, 245, 245));
		lblVotes.setBounds(493, 342, 86, 30);
		contentPane.add(lblVotes);
		
		textField = new JTextField();
		textField.setBounds(616, 130, 124, 25);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(616, 229, 124, 28);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(616, 288, 124, 28);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(616, 346, 124, 28);
		contentPane.add(textField_3);
		
		
	}
}
