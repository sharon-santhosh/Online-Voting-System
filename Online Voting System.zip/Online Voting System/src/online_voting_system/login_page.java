package online_voting_system;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class login_page extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login_page frame = new login_page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public login_page() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(350, 100, 750, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setUndecorated(true); //To remove frame outline
		
		textField = new JTextField();
		textField.setBounds(452, 182, 245, 44);
		contentPane.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(452, 264, 245, 44);
		contentPane.add(passwordField);
		
		JLabel lblUsername = new JLabel("Voter ID:");
		lblUsername.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 25));
		lblUsername.setForeground(new Color(25, 25, 112));
		lblUsername.setBackground(new Color(175, 238, 238));
		lblUsername.setBounds(324, 182, 126, 44);
		contentPane.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setForeground(new Color(25, 25, 112));
		lblPassword.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 25));
		lblPassword.setBounds(324, 264, 126, 44);
		contentPane.add(lblPassword);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setBackground(new Color(245, 245, 245));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnLogin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (textField.getText().isEmpty() || passwordField.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null,"Voter ID and Password must be provided...!");
				} else if (textField.getText().equals("admin") && passwordField.getText().equals("12345")) 
				{
					JOptionPane.showMessageDialog(null,"Login Successful as ADMIN");
					
					admin_homepage admin= new admin_homepage();
					admin.setVisible(true);
				}
				else {
					String userName = textField.getText();
	                String passWord = passwordField.getText();

                try{  
					Class.forName("com.mysql.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/online_voting_system","root","Sh@10m123");  
					Statement stmt=con.createStatement();

					java.sql.ResultSet rs=stmt.executeQuery("select count(name) ROW_COUNT from online_voting_system.user where name='"
															+userName+"'and password ='"+passWord+"'");
                	while (rs.next())
                    {
                      int c = (int) rs.getFloat(1);
                      if (c == 0)
                      {
                    	  JOptionPane.showMessageDialog(null,"Incorrect Username or Password provided.");
                    	  textField.setText(null);
          				  passwordField.setText(null);
                      }
                      else
                    	  {JOptionPane.showMessageDialog(null,"Login Successful as "+ userName);
                          voter_homepage userhome= new voter_homepage();
                          userhome.setVisible(true);
                    	  }
                    }
					con.close();  
					} catch(Exception e1){ System.out.println(e1);}
				}
			}
		});
		btnLogin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnLogin.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 20));
		btnLogin.setForeground(new Color(25, 25, 112));
		btnLogin.setBounds(346, 373, 104, 44);
		contentPane.add(btnLogin);
				
		JButton btnReset = new JButton("Reset");
		btnReset.setBackground(new Color(245, 245, 245));
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnReset.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnReset.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textField.setText(null);
				passwordField.setText(null);
			}
		});
		btnReset.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 20));
		btnReset.setForeground(new Color(25, 25, 112));
		btnReset.setBounds(467, 373, 104, 44);
		contentPane.add(btnReset);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(197, 129, 338, 2);
		contentPane.add(separator);
		
		JLabel lblNewLabel = new JLabel("LOGIN PAGE");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(25, 25, 112));
		lblNewLabel.setFont(new Font("Eras Light ITC", Font.BOLD, 50));
		lblNewLabel.setBounds(207, 55, 313, 63);
		contentPane.add(lblNewLabel);
		
		//Inserting an image
		JLabel lblNewLabel1 = new JLabel("");
		lblNewLabel1.setHorizontalAlignment(SwingConstants.CENTER);
		Image image= new ImageIcon(this.getClass().getResource("/team.png")).getImage();
		lblNewLabel1.setIcon(new ImageIcon(image));
		lblNewLabel1.setBounds(28, 161, 286, 256);
		contentPane.add(lblNewLabel1);
		
		JButton btnNewButton = new JButton("X");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(DISPOSE_ON_CLOSE);
			}
		});
		btnNewButton.setBackground(new Color(248, 248, 255));
		btnNewButton.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 15));
		btnNewButton.setForeground(new Color(128, 128, 128));
		btnNewButton.setBounds(702, 0, 48, 38);
		contentPane.add(btnNewButton);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.setBackground(new Color(245, 245, 245));
		btnRegister.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				register reg= new register();
				reg.setVisible(true);	
			}
		});
		btnRegister.setForeground(new Color(25, 25, 112));
		btnRegister.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 20));
		btnRegister.setBounds(593, 373, 104, 44);
		contentPane.add(btnRegister);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(197, 42, 338, 2);
		contentPane.add(separator_1);
	}
}


