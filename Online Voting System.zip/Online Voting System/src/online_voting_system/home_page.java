package online_voting_system;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.TitledBorder;

import online_voting_system.login_page;

import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;

public class home_page extends JFrame {

	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					home_page frame = new home_page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public home_page() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(350, 100, 750, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setUndecorated(true); //To remove frame outline
		
		JLabel lblNewLabel = new JLabel("ONLINE VOTING SYSTEM");
		lblNewLabel.setForeground(new Color(25, 25, 112));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Eras Light ITC", Font.BOLD, 50));
		lblNewLabel.setBounds(43, 79, 672, 72);
		contentPane.add(lblNewLabel);
		
		JLabel lblWelcome = new JLabel("Welcome!");
		lblWelcome.setForeground(new Color(119, 136, 153));
		lblWelcome.setFont(new Font("Lucida Calligraphy", Font.PLAIN, 43));
		lblWelcome.setHorizontalAlignment(SwingConstants.CENTER);
		lblWelcome.setBounds(439, 209, 258, 62);
		contentPane.add(lblWelcome);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(43, 162, 672, 2);
		contentPane.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(43, 66, 672, 2);
		contentPane.add(separator_1);
		
		JButton btnAdmin = new JButton("Admin");
		btnAdmin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login_page login= new login_page();
				login.setVisible(true);
			}
		});
		btnAdmin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnAdmin.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		btnAdmin.setBackground(new Color(176, 224, 230));
		btnAdmin.setForeground(new Color(25, 25, 112));
		btnAdmin.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 22));
		btnAdmin.setBounds(504, 302, 146, 51);
		contentPane.add(btnAdmin);
		
		JButton btnVoter = new JButton("Voter");
		btnVoter.setBackground(new Color(176, 224, 230));
		btnVoter.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnVoter.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		btnVoter.setForeground(new Color(25, 25, 112));
		btnVoter.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 22));
		btnVoter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login_page login= new login_page();
				login.setVisible(true);
			}
		});
		btnVoter.setBounds(504, 388, 146, 51);
		contentPane.add(btnVoter);
		
		JButton btnNewButton = new JButton("X");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(DISPOSE_ON_CLOSE);
			}
		});
		btnNewButton.setBackground(new Color(248, 248, 255));
		btnNewButton.setFont(new Font("Segoe UI Semilight", Font.PLAIN, 15));
		btnNewButton.setForeground(new Color(128, 128, 128));
		btnNewButton.setBounds(702, 0, 48, 38);
		contentPane.add(btnNewButton);
		
		//Inserting image
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBackground(new Color(255, 250, 250));
		Image voting_images= new ImageIcon(this.getClass().getResource("/star.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(voting_images));
		lblNewLabel_1.setBounds(31, 174, 431, 326);
		contentPane.add(lblNewLabel_1);
	}
}
